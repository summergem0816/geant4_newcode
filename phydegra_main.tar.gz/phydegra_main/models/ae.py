from torch import nn
from einops import rearrange

import numbers
import torch
import torch.nn.functional as F


def to_3d(x):
    return rearrange(x, "b c h w -> b (h w) c")


def to_4d(x, h, w):
    return rearrange(x, "b (h w) c -> b c h w", h=h, w=w)


class BiasFree_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super().__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)
        assert len(normalized_shape) == 1
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return x / torch.sqrt(sigma + 1e-5) * self.weight


class WithBias_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super().__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)
        assert len(normalized_shape) == 1
        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        mu = x.mean(-1, keepdim=True)
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma + 1e-5) * self.weight + self.bias


class LayerNorm(nn.Module):
    def __init__(self, dim, layer_norm_type):
        super().__init__()
        if layer_norm_type == "BiasFree":
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        h, w = x.shape[-2:]
        return to_4d(self.body(to_3d(x)), h, w)


class ResidualBlock(nn.Module):
    def __init__(self, in_dim, out_dim, padding_mode="zeros"):
        super().__init__()
        self.conv0 = nn.Conv2d(
            in_dim,
            out_dim,
            kernel_size=3,
            stride=1,
            padding=1,
            bias=False,
            padding_mode=padding_mode,
        )
        self.conv1 = nn.Conv2d(
            out_dim,
            out_dim,
            kernel_size=3,
            stride=1,
            padding=1,
            bias=False,
            padding_mode=padding_mode,
        )
        self.conv_out = nn.Conv2d(in_dim, out_dim, kernel_size=1, bias=False) if in_dim != out_dim else nn.Identity()
        self.norm0 = LayerNorm(in_dim, "WithBias")
        self.norm1 = LayerNorm(out_dim, "WithBias")
        self.act = nn.GELU()

    def forward(self, inp, use_skip=True):
        x = self.conv0(self.act(self.norm0(inp)))
        x = self.conv1(self.act(self.norm1(x)))
        return x + self.conv_out(inp) if use_skip else x


class ResidualBlockModule(nn.Module):
    def __init__(self, in_dim, out_dim, is_down):
        super().__init__()
        self.down = nn.Conv2d(in_dim, out_dim, kernel_size=3, stride=2, padding=1) if is_down else nn.Identity()
        self.rb0 = ResidualBlock(out_dim, out_dim)
        self.rb1 = ResidualBlock(out_dim, out_dim)
        self.beta = nn.Parameter(torch.zeros((1, out_dim, 1, 1)), requires_grad=True)
        self.gamma = nn.Parameter(torch.zeros((1, out_dim, 1, 1)), requires_grad=True)

    def forward(self, inp):
        inp = self.down(inp)
        x = self.rb0(inp)
        y = inp + self.beta * x
        x = self.rb1(y)
        return y + self.gamma * x


class Upsample(nn.Module):
    def __init__(self, in_dim, out_dim, is_up):
        super().__init__()
        self.rb0 = ResidualBlock(in_dim, in_dim)
        self.rb1 = ResidualBlock(in_dim, in_dim)
        self.up = (
            nn.Sequential(
                nn.Conv2d(in_dim, in_dim * 4, kernel_size=1),
                nn.PixelShuffle(2),
                nn.Conv2d(in_dim, out_dim, kernel_size=1),
            )
            if is_up
            else nn.Identity()
        )
        self.beta = nn.Parameter(torch.zeros((1, in_dim, 1, 1)), requires_grad=True)
        self.gamma = nn.Parameter(torch.zeros((1, in_dim, 1, 1)), requires_grad=True)

    def forward(self, inp):
        x = self.rb0(inp)
        y = inp + self.beta * x
        x = self.rb1(y)
        x = y + self.gamma * x
        return self.up(x)


class Encoder(nn.Module):
    def __init__(self, in_dim, base_dim, latent_dim):
        super().__init__()
        self.stem = nn.Conv2d(in_dim, base_dim, kernel_size=3, stride=1, padding=1)
        self.eb0 = ResidualBlockModule(base_dim, base_dim, False)
        self.eb1 = ResidualBlockModule(base_dim, base_dim, True)
        self.eb2 = ResidualBlockModule(base_dim, base_dim * 2, True)
        self.eb3 = ResidualBlockModule(base_dim * 2, base_dim * 4, True)
        self.conv_out = nn.Conv2d(base_dim * 4, latent_dim, kernel_size=3, stride=1, padding=1)

    def forward(self, inp):
        x = self.stem(inp)
        x = self.eb0(x)
        x = self.eb1(x)
        x = self.eb2(x)
        x = self.eb3(x)
        return self.conv_out(x)


class Decoder(nn.Module):
    def __init__(self, in_dim, base_dim, latent_dim):
        super().__init__()
        self.conv_in = nn.Conv2d(latent_dim, base_dim * 4, kernel_size=3, stride=1, padding=1)
        self.db0 = Upsample(base_dim * 4, base_dim * 2, is_up=True)
        self.db1 = Upsample(base_dim * 2, base_dim, is_up=True)
        self.db2 = Upsample(base_dim, base_dim, is_up=True)
        self.db3 = Upsample(base_dim, base_dim, is_up=False)
        self.refine = nn.Sequential(
            nn.GELU(),
            nn.Conv2d(base_dim, in_dim, kernel_size=3, padding=1, padding_mode="zeros"),
        )

    def forward(self, inp):
        x = self.conv_in(inp)
        x = self.db0(x)
        x = self.db1(x)
        x = self.db2(x)
        x = self.db3(x)
        return self.refine(x)


class EncoderSkip(nn.Module):
    def __init__(self, in_dim, base_dim, latent_dim):
        super().__init__()
        self.stem = nn.Conv2d(in_dim, base_dim, kernel_size=3, stride=1, padding=1)
        self.eb0 = ResidualBlockModule(base_dim, base_dim, False)
        self.eb1 = ResidualBlockModule(base_dim, base_dim, True)
        self.eb2 = ResidualBlockModule(base_dim, base_dim * 2, True)
        self.eb3 = ResidualBlockModule(base_dim * 2, base_dim * 4, True)
        self.conv_out = nn.Conv2d(base_dim * 4, latent_dim, kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        x = self.stem(x)
        f0 = self.eb0(x)
        f1 = self.eb1(f0)
        f2 = self.eb2(f1)
        x = self.eb3(f2)
        z = self.conv_out(x)
        return z, (f0, f1, f2)


class DecoderSkip(nn.Module):
    def __init__(self, in_dim, base_dim, latent_dim):
        super().__init__()
        self.conv_in = nn.Conv2d(latent_dim, base_dim * 4, kernel_size=3, stride=1, padding=1)
        self.db0 = Upsample(base_dim * 4, base_dim * 2, is_up=True)
        self.conv_cat2 = nn.Conv2d(base_dim * 4, base_dim * 2, kernel_size=1)
        self.db1 = Upsample(base_dim * 2, base_dim, is_up=True)
        self.conv_cat1 = nn.Conv2d(base_dim * 2, base_dim, kernel_size=1)
        self.db2 = Upsample(base_dim, base_dim, is_up=True)
        self.conv_cat0 = nn.Conv2d(base_dim * 2, base_dim, kernel_size=1)
        self.db3 = Upsample(base_dim, base_dim, is_up=False)
        self.refine = nn.Sequential(
            nn.GELU(),
            nn.Conv2d(base_dim, in_dim, kernel_size=3, padding=1, padding_mode="zeros"),
        )

    def forward(self, z, features):
        f0, f1, f2 = features
        x = self.conv_in(z)
        x = self.db0(x)
        x = torch.cat([x, f2], dim=1)
        x = self.conv_cat2(x)
        x = self.db1(x)
        x = torch.cat([x, f1], dim=1)
        x = self.conv_cat1(x)
        x = self.db2(x)
        x = torch.cat([x, f0], dim=1)
        x = self.conv_cat0(x)
        x = self.db3(x)
        return self.refine(x)


class GlobalDegradationEncoder(nn.Module):
    def __init__(self, in_dim, base_dim, global_dim):
        super().__init__()
        hidden = max(base_dim // 2, 32)
        self.stem = nn.Sequential(
            nn.Conv2d(in_dim, hidden, kernel_size=3, stride=1, padding=1),
            nn.GELU(),
            nn.Conv2d(hidden, hidden, kernel_size=3, stride=2, padding=1),
            nn.GELU(),
            nn.Conv2d(hidden, base_dim, kernel_size=3, stride=2, padding=1),
            nn.GELU(),
            nn.Conv2d(base_dim, base_dim, kernel_size=3, stride=2, padding=1),
            nn.GELU(),
        )
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.head = nn.Sequential(
            nn.Conv2d(base_dim, global_dim, kernel_size=1),
            nn.GELU(),
        )

    def forward(self, x):
        x = self.stem(x)
        x = self.pool(x)
        return self.head(x).flatten(1)


class LocalDegradationEncoder(nn.Module):
    def __init__(self, in_dim, base_dim, local_dim):
        super().__init__()
        hidden = max(base_dim // 2, 32)
        self.stem = nn.Conv2d(in_dim, hidden, kernel_size=3, stride=1, padding=1)
        self.block0 = ResidualBlockModule(hidden, hidden, False)
        self.block1 = ResidualBlockModule(hidden, hidden, True)
        self.block2 = ResidualBlockModule(hidden, base_dim, True)
        self.block3 = ResidualBlockModule(base_dim, base_dim, True)
        self.proj = nn.Conv2d(base_dim, local_dim, kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        x = self.stem(x)
        x = self.block0(x)
        x = self.block1(x)
        x = self.block2(x)
        x = self.block3(x)
        return self.proj(x)


class DegradationCompressor(nn.Module):
    def __init__(self, global_dim, local_dim, latent_dim):
        super().__init__()
        self.global_to_local = nn.Sequential(
            nn.Linear(global_dim, local_dim),
            nn.GELU(),
            nn.Linear(local_dim, local_dim),
        )
        self.fuse = nn.Sequential(
            nn.Conv2d(local_dim * 2, local_dim, kernel_size=3, stride=1, padding=1),
            nn.GELU(),
            nn.Conv2d(local_dim, latent_dim, kernel_size=3, stride=1, padding=1),
        )

    def forward(self, global_code, local_code):
        global_map = self.global_to_local(global_code).unsqueeze(-1).unsqueeze(-1)
        global_map = global_map.expand(-1, -1, local_code.shape[-2], local_code.shape[-1])
        return self.fuse(torch.cat([global_map, local_code], dim=1))


class Autoencoder(nn.Module):
    def __init__(
        self,
        in_dim,
        base_dim,
        latent_dim,
        use_skip,
        global_deg_dim=128,
        local_deg_dim=64,
    ):
        super().__init__()
        self.use_skip = use_skip
        if use_skip:
            self.content_encoder = EncoderSkip(in_dim, base_dim, latent_dim)
            self.reconstruction_decoder = DecoderSkip(in_dim, base_dim, latent_dim)
        else:
            self.content_encoder = Encoder(in_dim, base_dim, latent_dim)
            self.reconstruction_decoder = Decoder(in_dim, base_dim, latent_dim)

        self.global_degradation_encoder = GlobalDegradationEncoder(in_dim, base_dim, global_deg_dim)
        self.local_degradation_encoder = LocalDegradationEncoder(in_dim, base_dim, local_deg_dim)
        self.degradation_compressor = DegradationCompressor(global_deg_dim, local_deg_dim, latent_dim)

        # Keep legacy aliases so the rest of the code can be upgraded incrementally.
        self.encoder = self.content_encoder
        self.decoder = self.reconstruction_decoder

    def encode_content(self, x):
        if self.use_skip:
            z_c, features = self.content_encoder(x)
        else:
            z_c = self.content_encoder(x)
            features = None
        return {
            "z_c": z_c,
            "features": features,
            "clean_reference": x,
        }

    def encode_degradation(self, x):
        global_code = self.global_degradation_encoder(x)
        local_code = self.local_degradation_encoder(x)
        z_t = self.degradation_compressor(global_code, local_code)
        return {
            "z_t": z_t,
            "global_code": global_code,
            "local_code": local_code,
        }

    def reconstruct_from_content_degradation(self, z_t, content_features):
        if self.use_skip:
            return self.reconstruction_decoder(z_t, content_features)
        return self.reconstruction_decoder(z_t)

    def forward(self, hq, lq=None):
        content = self.encode_content(hq)
        output = dict(content)
        if lq is not None:
            degradation = self.encode_degradation(lq)
            output.update(degradation)
            output["reconstruction"] = self.reconstruct_from_content_degradation(
                degradation["z_t"],
                content["features"],
            )
        return output
