截止到1.6 对SAM模块的输出做了调整 有两个输出参数L和R（对应低光增强） 两个输出参数L、R在输入复原网络进行了concat 后续代码未调整

参数调整
1.options/train_FeMaSR_LQ_stage.yml
  16行(train)和41行(val)
    原内容：**dataroot_lq_mask**: datasets/ZZCX_3_3/train/lq_mask
    修改：  **dataroot_lq_mask_l**: datasets/ZZCX_3_3/train/lq_mask
            **dataroot_lq_mask_r**: datasets/ZZCX_3_3/train/lq_mask




数据处理代码调整
2.basicsr\data\paired_image_dataset.py 63行
    class PairedImageDataset(data.Dataset):
    def __init__(self, opt):
        63行
        原内容： self.gt_folder, self.lq_folder, self.lq_mask_folder = opt['dataroot_gt'], opt['dataroot_lq'], opt['dataroot_lq_mask']
        修改:    self.gt_folder, self.lq_folder, self.lq_mask_l_folder,self.lq_mask_r_folder = opt['dataroot_gt'], opt['dataroot_lq'], opt['dataroot_lq_mask_l'],opt['dataroot_lq_mask_r']

        77行 81行
        原内容： self.paths = paired_paths_from_meta_info_file(
                        [self.lq_folder,self.lq_mask_folder, self.gt_folder], ['lq', 'lq_mask', 'gt'],
                                        self.opt['meta_info_file'], self.filename_tmpl)

        修改：   self.paths = paired_paths_from_meta_info_file(
                        [self.lq_folder,self.lq_mask_l_folder, self.lq_mask_r_folder, self.gt_folder], ['lq', 'lq_mask_l', 'lq_mask_r', 'gt'],
                                        self.opt['meta_info_file'], self.filename_tmpl)


    def __getitem__(self, index):
        114行
        原内容： lq_mask_path = self.paths[index]['lq_mask_path']
                img_bytes = self.file_client.get(lq_mask_path, 'lq_mask')
                try:
                    img_lq_mask = imfrombytes(img_bytes, float32=True)
                except:
                    raise Exception("lq path {} not working".format(lq_path))

        修改为： lq_mask_l_path = self.paths[index]['lq_mask_l_path']
                img_bytes_l = self.file_client.get(lq_mask_l_path, 'lq_mask_l')
                try:
                    img_lq_mask_l = imfrombytes(img_bytes_l, float32=True)
                except:
                    raise Exception("lq_mask_l path {} not working".format(lq__mask_l_path))

                lq_mask_r_path = self.paths[index]['lq_mask_r_path']
                img_bytes_r = self.file_client.get(lq_mask_r_path, 'lq_mask_r')
                try:
                    img_lq_mask_r = imfrombytes(img_bytes_r, float32=True)
                except:
                    raise Exception("lq_mask_r path {} not working".format(lq_mask_r_path))

        145行、161行、167行、174行 只修改了对应的img_lq_mask
        原内容：img_gt, img_lq，img_lq_mask = cv2.resize(img_gt, (gt_size, gt_size)), cv2.resize(img_lq, (gt_size, gt_size)), cv2.resize(img_lq_mask，(gt_size,gt_size))
        修改为： img_gt, img_lq = cv2.resize(img_gt, (gt_size, gt_size)), cv2.resize(img_lq, (gt_size, gt_size)), 
                img_lq_mask_l,img_lq_mask_r = cv2.resize(img_lq_mask_l, (gt_size,gt_size)), cv2.resize(img_lq_mask_r, (gt_size,gt_size))

 
        151行 函数位于basicsr\data\transforms.py 也进行了调整
        原内容： img_gt, img_lq, img_lq_mask = paired_random_crop(img_gt, img_lq, img_lq_mask, gt_size, scale,gt_path)
        修改为： img_gt, img_lq, img_lq_mask_l,img_lq_mask_r = paired_random_crop(img_gt, img_lq, img_lq_mask_l,img_lq_mask_r gt_size, scale, gt_path)       
    
        156行 函数位于basicsr\data\transforms.py 也进行了调整
        原内容： img_gt, img_lq, img_lq_mask = random_augmentation(img_gt, img_lq, img_lq_mask)
        修改为： img_gt, img_lq, img_lq_mask_l,img_lq_mask_r = random_augmentation(img_gt, img_lq, img_lq_mask_l,img_lq_mask_r)

3.basicsr\data\transforms.py
    def paired_random_crop
        49行、55行、87行、101行、107行
        原内容：def paired_random_crop(img_gts, img_lqs, img_lqs_mask, lq_patch_size, scale, gt_path):
        修改为：def paired_random_crop(img_gts, img_lqs, img_lqs_mask_l,img_lqs_mask_r, lq_patch_size, scale, gt_path):




模型代码调整
4.train.py 203行 model = build_model(opt)
    basicsr/models/femasr_model.py
    94行 def feed_data(self, data)
        原内容： self.lq_mask = data['lq_mask'].to(self.device)
        修改:    self.lq_mask_l = data['lq_mask_l'].to(self.device)
                self.lq_mask_r = data['lq_mask_r'].to(self.device)  
    
    105行 def optimize_parameters(self, current_iter):
        原内容：self.output = self.net_g(self.lq, self.lq_mask)
        修改:   self.output = self.net_g(self.lq, self.lq_mask_l,self.lq_mask_r)

5.basicsr\models\femasr_model.py
    26行 self.net_g = build_network(opt['network_g'])
    对应basicsr\archs\femasr_arch.py


6.basicsr\archs\femasr_arch.py

IRNet	   Net        输入LQ和多尺度特征的复原网络 对应图2.a
PPFGNet    Mask_Feature_Representation	 多尺度特征 
IN2PPT     InterBlock	      IN2PPT+(InterPPA+PPFN)*2  对应一个完整的子模块 一共有五个这种子模块

IntraPPA	Self_Attention	  通过 Dual_Direction_Fusion 实现特征交互 

InterPPA	Cross_Attention	   显式学习 parser 特征的分支 

PPFN	Mask_Aware_FeedForward	带有门控调制机制的反馈网络 





basicsr\archs\femasr_arch.py

    class FeMaSRNet(nn.Module):
    def __init__
    893行
            self.Mask_Feature_Representation = Mask_Feature_Representation(
                    in_channel=3,
                    max_depth=2,
                    input_res=128,
                    channel_query_dict,
                    bias=bias)
        改为
            self.Mask_Feature_Representation_L = Mask_Feature_Representation(
                in_channel=3,
                max_depth=2,
                input_res=128,
                channel_query_dict=channel_query_dict,
                bias=bias)
            self.Mask_Feature_Representation_R = Mask_Feature_Representation(
                in_channel=3,
                max_depth=2,
                input_res=128,
                channel_query_dict=channel_query_dict,
                bias=bias)

    def encode_and_decode(self, input, input_mask, current_iter=None):
    929行
            Mask_Feature_Representation = self.Mask_Feature_Representation(input_mask)
            restoration = self.restoration_network(input, Mask_Feature_Representation)

        改为
            def encode_and_decode(self, input, input_mask_l,input_mask_r, current_iter=None):
                Mask_Feature_Representation_L = self.Mask_Feature_Representation(input_mask_l)
                Mask_Feature_Representation_R = self.Mask_Feature_Representation(input_mask_r)
                restoration = self.restoration_network(input, Mask_Feature_Representation_L,Mask_Feature_Representation_R)


    def forward(self, input, input_mask):
    1027行
            def forward(self, input, input_mask):
                restoration = self.encode_and_decode(input, input_mask)
        改为
            def forward(self, input, input_mask_l,input_mask_r):
                restoration = self.encode_and_decode(input, input_mask_l,input_mask_r)
    
    修改self.encode_and_decode对应的Net类
    class Net(nn.Module):
    def forward(self, x, mask_representatin_features):
    799行
            def forward(self, x, mask_representatin_features):
        改为
            def forward(self, x, mask_representatin_features_l,mask_representatin_features_r):

    803行、808行、813行、817行、822行
            en_block1 = self.en_block1(enter, mask_representatin_features_[0])
        改为
            en_block1 = self.en_block1(enter, mask_representatin_features_l[0],mask_representatin_features_r[0])

    修改self.en_block1对应的InterBlock类
    class InterBlock(nn.Module):
    def __init__
    656行
        #1.6暂时添加 后期删除
        self.mask_fusion = nn.Conv2d(dim * 2, dim, 1, bias=bias)

    def fusion
    668行
            x_mask = self.norm_mask(x_mask)
        改为
            x_mask_l = self.norm_mask(x_mask_l)
            x_mask_r = self.norm_mask(x_mask_r)
            #1.6暂时添加 后期删除
            x_mask = self.mask_fusion(torch.cat([x_mask_l, x_mask_r], dim=1))

    def forward
    670行
            def forward(self, x, x_mask):
                fusion = self.fusion(x, x_mask)
        改为
            def forward(self, x, x_mask_l,x_mask_r):
                fusion = self.fusion(x, x_mask_l,x_mask_r)








