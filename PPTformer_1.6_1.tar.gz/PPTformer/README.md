# PPTformer
[AAAI-25] Intra and Inter Parser-Prompted Transformers for Effective Image Restoration

Cong Wang, Jinshan Pan, Liyan Wang, Wei Wang

Visual results are available at: https://drive.google.com/drive/folders/1t14-nSF1z73IwGWHqA-yF726-UkdOPsb?usp=sharing
