import math

import torch
import torch.nn as nn
import torch.nn.functional as F


def _normalize_kernel(kernel: torch.Tensor) -> torch.Tensor:
    kernel = torch.clamp(kernel, min=0.0)
    return kernel / kernel.sum().clamp_min(1e-8)


def gaussian_kernel2d(
    kernel_size: int,
    sigma_x: float,
    sigma_y: float,
    device: torch.device,
    dtype: torch.dtype,
) -> torch.Tensor:
    radius = kernel_size // 2
    coords = torch.arange(-radius, radius + 1, device=device, dtype=dtype)
    yy, xx = torch.meshgrid(coords, coords, indexing="ij")
    kernel = torch.exp(
        -0.5 * ((xx / max(sigma_x, 1e-6)) ** 2 + (yy / max(sigma_y, 1e-6)) ** 2)
    )
    return _normalize_kernel(kernel)


def _conv_same(x: torch.Tensor, kernel: torch.Tensor) -> torch.Tensor:
    channels = x.shape[1]
    weight = kernel[None, None, :, :].to(device=x.device, dtype=x.dtype).repeat(channels, 1, 1, 1)
    padding = kernel.shape[-1] // 2
    return F.conv2d(x, weight, padding=padding, groups=channels)


class NeutronPhysicalForward(nn.Module):
    def __init__(
        self,
        blur_kernel_size: int = 21,
        blur_sigma_min: float = 0.8,
        blur_sigma_max: float = 2.5,
        scatter_kernel_size: int = 81,
        scatter_sigma: float = 12.0,
        scatter_strength_max: float = 0.08,
        readout_sigma_max: float = 0.01,
        flux_min: float = 1.0e4,
        flux_max: float = 3.0e5,
    ):
        super().__init__()
        self.blur_kernel_size = blur_kernel_size
        self.blur_sigma_min = blur_sigma_min
        self.blur_sigma_max = blur_sigma_max
        self.scatter_kernel_size = scatter_kernel_size
        self.scatter_sigma = scatter_sigma
        self.scatter_strength_max = scatter_strength_max
        self.readout_sigma_max = readout_sigma_max
        self.flux_min = flux_min
        self.flux_max = flux_max

    def _latent_strength(
        self,
        degradation_latent: torch.Tensor | None,
        batch_size: int,
        device: torch.device,
        dtype: torch.dtype,
    ) -> torch.Tensor:
        if degradation_latent is None:
            return torch.zeros(batch_size, device=device, dtype=dtype)
        dims = tuple(range(1, degradation_latent.ndim))
        strength = degradation_latent.abs().mean(dim=dims)
        return torch.sigmoid(strength)

    def _map_t_to_sigma(self, t: torch.Tensor) -> torch.Tensor:
        return self.blur_sigma_min + (self.blur_sigma_max - self.blur_sigma_min) * t

    def _map_t_to_flux(self, t: torch.Tensor) -> torch.Tensor:
        return self.flux_max - (self.flux_max - self.flux_min) * t

    def _map_t_to_readout(self, t: torch.Tensor) -> torch.Tensor:
        return self.readout_sigma_max * t

    def _map_t_to_scatter_strength(self, t: torch.Tensor) -> torch.Tensor:
        return self.scatter_strength_max * t

    def apply_blur(self, x: torch.Tensor, sigma: torch.Tensor) -> torch.Tensor:
        outputs = []
        for idx in range(x.shape[0]):
            kernel = gaussian_kernel2d(
                self.blur_kernel_size,
                sigma_x=float(sigma[idx].item()),
                sigma_y=float(sigma[idx].item()),
                device=x.device,
                dtype=x.dtype,
            )
            outputs.append(_conv_same(x[idx:idx + 1], kernel))
        return torch.cat(outputs, dim=0)

    def apply_scatter_background(self, x: torch.Tensor, t: torch.Tensor) -> torch.Tensor:
        kernel = gaussian_kernel2d(
            self.scatter_kernel_size,
            sigma_x=self.scatter_sigma,
            sigma_y=self.scatter_sigma,
            device=x.device,
            dtype=x.dtype,
        )
        scatter_base = _conv_same(x, kernel)
        strength = self._map_t_to_scatter_strength(t).view(-1, 1, 1, 1)
        return strength * scatter_base

    def apply_poisson_noise(self, x: torch.Tensor, t: torch.Tensor, sample_noise: bool = True) -> torch.Tensor:
        flux = self._map_t_to_flux(t).view(-1, 1, 1, 1)
        expected_counts = torch.clamp(x, min=0.0) * flux
        if sample_noise:
            sampled = torch.poisson(expected_counts)
        else:
            sampled = expected_counts
        return sampled / flux.clamp_min(1e-8)

    def apply_readout_noise(self, x: torch.Tensor, t: torch.Tensor, sample_noise: bool = True) -> torch.Tensor:
        if not sample_noise:
            return x
        sigma = self._map_t_to_readout(t).view(-1, 1, 1, 1)
        return x + torch.randn_like(x) * sigma

    def forward(
        self,
        clean: torch.Tensor,
        t: torch.Tensor,
        degradation_latent: torch.Tensor | None = None,
        sample_noise: bool = True,
    ) -> dict[str, torch.Tensor]:
        transmission = clean.clamp(-1.0, 1.0).add(1.0).div(2.0)
        latent_strength = self._latent_strength(
            degradation_latent,
            batch_size=clean.shape[0],
            device=clean.device,
            dtype=clean.dtype,
        )
        effective_t = torch.clamp(t + 0.15 * (latent_strength - 0.5), 0.0, 1.0)
        sigma = self._map_t_to_sigma(effective_t)
        blurred = self.apply_blur(transmission, sigma)
        scatter = self.apply_scatter_background(blurred, effective_t)
        degraded = self.apply_poisson_noise(blurred + scatter, effective_t, sample_noise=sample_noise)
        degraded = self.apply_readout_noise(degraded, effective_t, sample_noise=sample_noise)
        degraded = degraded.clamp(0.0, 1.0).mul(2.0).sub(1.0)
        return {
            "transmission": transmission,
            "blurred": blurred,
            "scatter": scatter,
            "effective_t": effective_t,
            "degraded": degraded,
        }
